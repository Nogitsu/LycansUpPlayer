# LycansUpPlayer

Ce mod permet de créer des parties multijoueurs à plus de 10 joueurs.